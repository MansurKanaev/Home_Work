package tasks;

public class PleaseDeleteMeAndImplement extends RuntimeException {
}
