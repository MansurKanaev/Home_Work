class Main {
    public static void main(String[] args) {
        System.out.println("Please use tests to run the program");
    }
}
